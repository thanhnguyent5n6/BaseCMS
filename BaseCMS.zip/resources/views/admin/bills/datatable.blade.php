<div class="kt-datatable" id="local_data"></div>
@include('admin.bills.script')
