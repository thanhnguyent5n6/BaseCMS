var WebCommon = function () {
    var LangSwitch = function () {

    }

    return {
        init: function () {
            LangSwitch();
        }
    };

}();
